<?php
echo"<a href=main.php><div id='NAGLOWEK'><img src='images/logo.png' class=srodek></div></a>
	<a href=wyloguj.php><div id='wyloguj'>Wyloguj</div></a>
	<div id='MENU'>
		  <ol>
			  <li><a href=''>MAGAZYN</a>
			  <ul>
						<li><a href='#'>Zamów towar</a></li>
						<li><a href='sprawdz_stan_magazynu.php'>Sprawdź stan</a></li>
						<li><a href='zmien_stan_zamowienia.php'>Realizuj zamówienie</a></li>
					</ul>
			  </li>
			  <li><a href=''>FAKTURY/ZESTAWIENIA</a>
			  <ul>
						<li><a href='#'>Generuj fakturę</a></li>
						<li><a href='#'>Generuj zestawienie</a></li>
					</ul>
			  </li>
			  <li><a href=''>INNE</a>
			  <ul>
						<li><a href='#'>Wyszukaj produkt</a></li>
						<li><a href='#'>Edytuj dane osobowe</a></li>
					</ul>
			  </li>
		</ol></div></br>";
?>