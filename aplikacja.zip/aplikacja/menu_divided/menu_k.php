<?php
echo"<a href=main.php><div id='NAGLOWEK'><img src='images/logo.png' class=srodek></div></a>
	<a href=wyloguj.php><div id='wyloguj'>Wyloguj</div></a>
	<div id='MENU'>
		  <ol>
			  <li><a href=''>ZAMÓWIENIA</a>
			  <ul>
						<li><a href='wyswietl_produkty.php'>Złóż zamówienie</a></li>
						<li><a href='#'>Podgląd zamówień</a></li>
						<li><a href='pokaz_koszyk.php'>Pokaż koszyk</a></li>
						<li><a href='sprawdz_stan_zamowienia.php'>Sprawdź stan realizacji</a></li>
					</ul>
			  </li>
			  <li><a href=''>FAKTURY/ZESTAWIENIA</a>
			  <ul>
						<li><a href='#'>Generuj fakturę</a></li>
						<li><a href='#'>Wyślij  fakturę na email</a></li>
						<li><a href='#'>Generuj zestawienie</a></li>
						<li><a href='#'>Pobierz fakturę</a></li>
					</ul>
			  </li>
			  <li><a href=''>INNE</a>
			  <ul>
						<li><a href='#'>Wyszukaj produkt</a></li>
						<li><a href='#'>Edytuj dane osobowe</a></li>
					</ul>
			  </li>
		</ol></div></br>";
?>